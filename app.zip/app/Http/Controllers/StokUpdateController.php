<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StokUpdateController extends Controller
{
    //
}
